'use strict';
const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const svgIcon = (name, cls='i') => `<svg class="${cls}" aria-hidden="true"><use href="/static/assets/icons.svg#${name}"></use></svg>`;
const esc = (value='') => String(value??'').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const assetUrl = url => window.__assetMap?.[url] || url;
const state = {settings:{},products:[],videos:[],social_posts:[],fbFilter:'all',filter:'الكل',search:'',sort:'featured',cart:[],currentProduct:null};
try{state.cart=JSON.parse(localStorage.getItem('furat_cart')||'[]');if(!Array.isArray(state.cart))state.cart=[];}catch{state.cart=[];}
const categoryStyles = {
  'الهواتف':['#e6f1fc','#3876c8','phone'],
  'السماعات':['#f1eafa','#8e6ad6','headphones'],
  'الساعات الذكية':['#eaf7f3','#24a398','watch'],
  'الشواحن':['#fff1e6','#df9162','charger'],
  'الإكسسوارات':['#edf1fa','#617dc5','case'],
  'الباور بانك':['#e7f2fd','#2a6cc5','powerbank'],
  'إكسسوارات السيارات':['#f3eefb','#7164d3','car'],
  'مستلزمات الكمبيوتر':['#e4f4fb','#276b9e','laptop']
};
const styleFor=(cat)=>categoryStyles[cat]||['#eaf4fa','#388cb0','phone'];
const productArt=(cat)=>{
  const [bg, color, kind]=styleFor(cat);
  let illustration='';
  if(kind==='phone') illustration=`<rect x="51" y="10" rx="18" width="91" height="165" fill="#0b2b49" stroke="#659cc4" stroke-width="5"/><rect x="58" y="18" rx="13" width="77" height="148" fill="url(#scr)"/><path d="M58 128c55-94 70 14 77-65v104H58Z" fill="#34d6ee" opacity=".8"/><rect x="77" y="20" width="39" height="9" rx="5" fill="#071c30"/><circle cx="96" cy="157" r="2" fill="#b3e5f1"/>`;
  else if(kind==='headphones') illustration=`<path d="M33 96V73a64 64 0 0 1 128 0v23" fill="none" stroke="${color}" stroke-width="20" stroke-linecap="round"/><rect x="20" y="87" width="37" height="63" rx="18" fill="#264765" stroke="#b8c4ef" stroke-width="5"/><rect x="136" y="87" width="37" height="63" rx="18" fill="#264765" stroke="#b8c4ef" stroke-width="5"/><rect x="33" y="101" width="20" height="39" rx="10" fill="#a4c8e8"/><rect x="140" y="101" width="20" height="39" rx="10" fill="#a4c8e8"/>`;
  else if(kind==='watch') illustration=`<rect x="74" y="4" width="48" height="54" rx="10" fill="#568b90"/><rect x="74" y="135" width="48" height="55" rx="10" fill="#568b90"/><rect x="53" y="46" width="90" height="101" rx="25" fill="#1a3e56" stroke="#9be3d7" stroke-width="7"/><rect x="63" y="55" width="70" height="82" rx="19" fill="url(#scr)"/><circle cx="98" cy="94" r="20" fill="none" stroke="#50fff1" stroke-width="5"/><path d="M98 75v20l11 7" stroke="#ddfbfd" stroke-width="5" fill="none" stroke-linecap="round"/>`;
  else if(kind==='charger') illustration=`<path d="M85 8v34M113 8v34" stroke="#7baac4" stroke-width="13" stroke-linecap="round"/><rect x="58" y="33" rx="16" width="84" height="112" fill="#e5f7fe" stroke="#a7c1ca" stroke-width="5"/><rect x="69" y="50" rx="8" width="61" height="77" fill="#f8fdff"/><path d="m102 60-20 35h20l-8 25 26-39h-19Z" fill="${color}"/><path d="M98 145v35" stroke="#96b4c4" stroke-width="7" stroke-linecap="round"/>`;
  else illustration=`<rect x="49" y="13" rx="22" width="97" height="164" fill="#293b69" stroke="#9ac1ff" stroke-width="7"/><rect x="60" y="24" rx="16" width="75" height="140" fill="url(#scr)"/><circle cx="97" cy="94" r="29" fill="#acc9ed" opacity=".55"/><rect x="65" y="36" rx="8" width="29" height="38" fill="#274566"/><circle cx="76" cy="48" r="6" fill="#9db8d6"/><circle cx="76" cy="63" r="5" fill="#9db8d6"/>`;
  return `<svg class="category-art-svg" viewBox="0 0 194 194" aria-hidden="true"><defs><linearGradient id="scr" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#07466e"/><stop offset=".45" stop-color="${color}"/><stop offset="1" stop-color="#0a204b"/></linearGradient></defs><ellipse cx="96" cy="182" rx="70" ry="8" fill="#082b4a" opacity=".14"/>${illustration}</svg>`;
};
const realisticIcon=(cat)=>{const kind=styleFor(cat)[2];return `<img class="category-realistic-device" src="${esc(assetUrl(`/static/assets/category-icons/${kind}.svg`))}" alt="" loading="lazy" />`;};
const houseClips=[
 {id:'promo-m60',title:'نظرة على M60 PLUS',description:'مقطع دعائي متحرك صُنع من صورة إعلان المتجر، وليس من فيسبوك.',url:'/static/assets/reels/m60-plus.mp4',thumbnail_url:'/static/assets/ads/m60-plus.webp',origin:'creative'},
 {id:'promo-m45',title:'تعرف على M45S',description:'مقطع دعائي متحرك صُنع من صورة إعلان المتجر، وليس من فيسبوك.',url:'/static/assets/reels/m45s.mp4',thumbnail_url:'/static/assets/ads/m45s.webp',origin:'creative'},
 {id:'promo-romoss',title:'باور بانك راموس',description:'مقطع دعائي متحرك صُنع من صورة إعلان المتجر، وليس من فيسبوك.',url:'/static/assets/reels/romoss-j35.mp4',thumbnail_url:'/static/assets/ads/romoss-j35.webp',origin:'creative'}
];
function clipUrl(raw){return /^\/static\/assets\/reels\/[a-z0-9-]+\.mp4$/.test(raw||'')?raw:'';}
function allStoreVideos(){const fbFromPosts=state.social_posts.filter(p=>p.post_type==='video'&&isFacebookLink(p.url)).map(p=>({id:'post:'+p.id,title:p.title,description:p.description,url:p.url,thumbnail_url:p.image_url,origin:'facebook'}));return [...fbFromPosts,...state.videos,...houseClips];}
const money=(p)=>Number(p)>0?new Intl.NumberFormat('ar-YE',{maximumFractionDigits:2}).format(Number(p))+' '+esc(state.settings.currency||'ر.ي'):'السعر عند الطلب';
function toast(message){const el=$('#toast');el.textContent=message;el.classList.add('show');clearTimeout(toast._id);toast._id=setTimeout(()=>el.classList.remove('show'),3000);}
function whatsappNumber(value) {
  const digits = String(value ?? '').replace(/[٠-٩۰-۹]/g, digit => String(digit.charCodeAt(0) & 15)).replace(/\D/g, '');
  const number = digits.replace(/^00/, '');
  const local = number.replace(/^0/, '');
  if (/^7\d{8}$/.test(local)) return '967' + local;
  return /^[1-9]\d{7,14}$/.test(number) ? number : '';
}

function inquireAboutCart() {
  const number = whatsappNumber(state.settings.whatsapp);
  if (!number || !state.cart.length) return;

  const items = state.cart.map(({id, quantity}) => {
    const product = state.products.find(product => product.id === id);
    return `• ${product.name} × ${quantity}`;
  });
  const url = new URL('https://wa.me/' + number);
  url.searchParams.set('text', [
    'مرحباً الفرات موبايل، أود الاستفسار عن السعر والتوفر للمنتجات التالية:',
    ...items
  ].join('\n'));
  window.open(url.href, '_blank', 'noopener,noreferrer');
}
function externalUrl(value){try{const u=new URL(value);return /^https?:$/.test(u.protocol)?u.href:'';}catch{return '';}}
function videoId(raw){try{const u=new URL(raw);const host=u.hostname.toLowerCase();if(['youtu.be','www.youtu.be'].includes(host))return u.pathname.split('/')[1]?.match(/^[\w-]{11}$/)?.[0]||'';if(['youtube.com','www.youtube.com','m.youtube.com','youtube-nocookie.com','www.youtube-nocookie.com'].includes(host)){const id=u.searchParams.get('v')||(u.pathname.match(/\/(?:shorts|embed|live)\/([\w-]{11})/)||[])[1];return /^[\w-]{11}$/.test(id||'')?id:'';}}catch{}return '';}
function applySettings(){const s=state.settings;$('#brand-name').innerHTML=esc(s.store_name||'الفرات موبايل').replace('موبايل','<em>موبايل</em>');$('#brand-subtitle').textContent=s.store_subtitle||'';$('#announcement').textContent=s.announcement||'';$('#hero-title').innerHTML=esc(s.hero_title||'تقنيتك تبدأ من هنا').replace(/(تبدأ من هنا|من هنا|التقنية)/,'<span class="gradient-text">$1</span>');$('#hero-description').textContent=s.hero_description||'';$('#store-address').textContent=s.address||'العنوان يضاف من لوحة التحكم';$('#delivery-note').textContent=s.delivery_text||'اسأل عن التوصيل';$('#footer-payment').textContent=s.payment_text||'';$('#current-year').textContent=new Date().getFullYear();document.title=(s.store_name||'الفرات موبايل')+' | '+(s.store_subtitle||'متجر التقنية');
 const brand=$('#header-logo-image');if(s.logo_url){brand.src=s.logo_url;brand.classList.remove('hidden');$('.default-brand').classList.add('hidden');brand.onerror=()=>{brand.classList.add('hidden');$('.default-brand').classList.remove('hidden');};}
 if(s.phone){$('#store-phone-wrap').hidden=false;$('#store-phone').textContent=s.phone;}
 const wa=whatsappNumber(s.whatsapp);if(wa){$('#whatsapp-cta').href='https://wa.me/'+wa;$('#whatsapp-cta').target='_blank';$('#whatsapp-cta').rel='noopener noreferrer';}else{$('#whatsapp-cta').addEventListener('click',ev=>{ev.preventDefault();toast('لم يتم إضافة رقم واتساب بعد. يمكنك إرسال طلب عبر السلة.');});}
 const socials=['whatsapp','instagram','facebook','tiktok','youtube','telegram','snapchat','x'];const icons={x:'external',snapchat:'external'};$('#social-links').innerHTML=socials.map(platform=>{const u=platform==='whatsapp'?(wa?'https://wa.me/'+wa:''):externalUrl(s[platform]);return u?`<a target="_blank" rel="noopener noreferrer" href="${esc(u)}" aria-label="${platform}" title="${platform}">${svgIcon(icons[platform]||platform)}</a>`:'';}).join('');
 const fb=externalUrl(s.facebook);for(const id of ['facebook-section-link','facebook-follow-btn']){const el=$('#'+id);if(el&&fb)el.href=fb;}
 const page=externalUrl(s.facebook_page_url);if(page){try{const u=new URL(page);const host=u.hostname.replace(/^www\./,'').toLowerCase();const valid=host==='facebook.com'&&!u.pathname.startsWith('/share/')&&u.pathname.length>2;if(valid){$('#facebook-embed-wrapper').hidden=false;$('#facebook-embed').src='https://www.facebook.com/plugins/page.php?href='+encodeURIComponent(page)+'&tabs=timeline&width=500&height=520&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=false';}}catch{}}
 const yt=externalUrl(s.youtube);if(yt){$('#youtube-channel-link').href=yt;$('#youtube-channel-link').target='_blank';$('#youtube-channel-link').rel='noopener noreferrer';}else{$('#youtube-channel-link').hidden=true;}
 const app=externalUrl(s.app_url);if(app){$('#app-link-footer').hidden=false;$('#app-link-footer').href=app;$('#app-link-footer').target='_blank';$('#app-link-footer').rel='noopener noreferrer';}
}
function reveal(){if(!('IntersectionObserver' in window)){$$('.reveal').forEach(x=>x.classList.add('visible'));return;}const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');io.unobserve(e.target);}}),{threshold:.12});$$('.reveal').forEach(x=>io.observe(x));}
function allCategories(){const cats=[...new Set(state.products.map(p=>p.category))];const priority=Object.keys(categoryStyles);return [...priority.filter(x=>cats.includes(x)),...cats.filter(x=>!priority.includes(x))];}
function renderCategories(){const categories=allCategories();$('#category-cards').innerHTML=categories.map((cat,index)=>{const [bg,color]=styleFor(cat);const num=state.products.filter(p=>p.category===cat).length;return `<button class="category-card" data-category="${esc(cat)}" style="--cat-bg:${bg};--cat-color:${color};animation-delay:${index*55}ms"><span class="category-link">${svgIcon('arrow-left')}</span><div class="category-icon-wrap">${realisticIcon(cat)}</div><h3>${esc(cat)}</h3><small>${num} منتج</small></button>`;}).join('');$$('.category-card').forEach(b=>b.onclick=()=>{state.filter=b.dataset.category;renderFilters();renderProducts();$('#products').scrollIntoView({behavior:'smooth'});});}
function renderFilters(){const cs=['الكل',...allCategories()];$('#category-filters').innerHTML=cs.map(c=>`<button type="button" class="filter-chip ${state.filter===c?'active':''}" data-filter="${esc(c)}">${c==='الكل'?'الكل':esc(c)}</button>`).join('');$$('.filter-chip').forEach(x=>x.onclick=()=>{state.filter=x.dataset.filter;renderFilters();renderProducts();});}
function imageFor(p){if(p.image_url)return `<img class="product-img-real" src="${esc(p.image_url)}" alt="${esc(p.name)}" loading="lazy" onerror="this.style.display='none'" />`;return `<div class="product-illustration product-illustration-real">${realisticIcon(p.category)}</div>`;}
function renderProducts(){let all=state.products.filter(p=>(state.filter==='الكل'||p.category===state.filter)&&(p.name+' '+p.description+' '+p.category+' '+(p.brand||'')+' '+(p.model||'')+' '+Object.values(p.specs||{}).join(' ')).toLocaleLowerCase('ar').includes(state.search.toLocaleLowerCase('ar')));if(state.sort==='price-low')all.sort((a,b)=>a.price-b.price);else if(state.sort==='price-high')all.sort((a,b)=>b.price-a.price);else if(state.sort==='name')all.sort((a,b)=>a.name.localeCompare(b.name,'ar'));else if(state.sort==='newest')all.sort((a,b)=>b.created_at.localeCompare(a.created_at));else all.sort((a,b)=>b.featured-a.featured||b.created_at.localeCompare(a.created_at));$('#products-total').textContent=`${all.length} منتج`;$('#product-grid').innerHTML=all.map((p,i)=>`<article class="product-card" style="animation-delay:${Math.min(i*32,280)}ms"><div class="product-image">${p.badge?`<span class="product-badge">${esc(p.badge)}</span>`:''}<button class="product-quick" aria-label="عرض تفاصيل ${esc(p.name)}" data-quick="${esc(p.id)}">${svgIcon('eye')}</button>${imageFor(p)}</div><div class="product-details"><span class="product-category">${esc(p.category)}</span><h3 title="${esc(p.name)}">${esc(p.name)}</h3><p class="product-description">${esc(p.description)}</p><div class="product-price-line"><div><strong class="product-price ${p.price?'':'ask'}">${money(p.price)}</strong>${Number(p.old_price)>Number(p.price)&&Number(p.price)>0?`<span class="old-price">${money(p.old_price)}</span>`:''}${p.stock===0?'<span class="stock-label">نفدت الكمية</span>':''}</div><button class="product-add" data-add="${esc(p.id)}" ${p.stock===0?'disabled':''} aria-label="إضافة ${esc(p.name)} إلى السلة">${svgIcon('plus')}</button></div></div></article>`).join('');$('#products-empty').hidden=all.length!==0;$$('[data-add]').forEach(b=>b.onclick=()=>addCart(b.dataset.add));$$('[data-quick]').forEach(b=>b.onclick=()=>openQuick(b.dataset.quick));}
function renderVideos(){
 const videos=allStoreVideos();
 $('#videos-grid').innerHTML=videos.length?videos.map(v=>{
  const id=videoId(v.url);const thumb=v.thumbnail_url||(id?`https://i.ytimg.com/vi/${id}/hqdefault.jpg`:'');
  const platform=v.origin==='creative'?'إعلان متحرك من أرشيف المتجر':id?'يوتيوب':isFacebookLink(v.url)?'فيديو فيسبوك':'فيديو خارجي';
  return `<article class="video-card ${v.origin==='creative'?'promo-clip-card':''}"><button type="button" class="video-thumb" data-video="${esc(v.id)}" aria-label="تشغيل ${esc(v.title)}">${thumb?`<img src="${esc(assetUrl(thumb))}" alt="${esc(v.title)}" loading="lazy" />`:'<span class="video-placeholder-icon">▶</span>'}<span class="play-circle">${svgIcon('play')}</span><span class="video-tape-mark">${v.origin==='creative'?'من تصاميم المتجر':isFacebookLink(v.url)?'Facebook':'فيديو'}</span></button><div class="video-body"><span class="video-platform">${esc(platform)}</span><h3>${esc(v.title)}</h3><p>${esc(v.description)}</p></div></article>`;
 }).join(''):'<div class="videos-empty">لا توجد فيديوهات بعد.</div>';
 $$('[data-video]').forEach(b=>b.onclick=()=>openVideo(b.dataset.video));
}

function renderFacebook(){
 const container=$('#facebook-gallery');if(!container)return;
 const media=state.social_posts.filter(p=>state.fbFilter==='all'||p.post_type===state.fbFilter);
 container.innerHTML=media.length?media.map(p=>{
 const link=externalUrl(p.url), img=p.image_url&&(/^(\/static\/assets\/ads\/|\/uploads\/)/.test(p.image_url)||/^data:image\/(?:png|jpeg|webp|svg\+xml);base64,/i.test(p.image_url)||externalUrl(p.image_url))?p.image_url:'';
 const label=p.source==='facebook'?'منشور فيسبوك':'تصميم إعلاني للمتجر';
 return `<article class="fb-media-card"><div class="fb-media-image">${img?`<img src="${esc(assetUrl(img))}" alt="${esc(p.title)}" loading="lazy">`:`<div class="fb-media-placeholder"><b>f</b><span>${p.post_type==='video'?'فيديو فيسبوك':'منشور'}</span></div>`}<span class="fb-post-badge">${p.post_type==='video'?'▶ فيديو':p.post_type==='post'?'منشور':'✦ إعلان'}</span></div><div class="fb-media-info"><small>${esc(label)}</small><h3>${esc(p.title)}</h3><p>${esc(p.description)}</p>${link?`${p.post_type==='video'?`<button type="button" class="fb-video-play" data-fb-video="${esc(p.id)}">${svgIcon('play')} تشغيل الفيديو</button>`:''}<a class="fb-media-link" href="${esc(link)}" target="_blank" rel="noopener noreferrer">فتح الأصل على فيسبوك ↗</a>`:'<span class="fb-media-muted">تصميم من أرشيف المتجر</span>'}</div></article>`;
 }).join(''):'<div class="fb-media-empty">لم يتم إضافة منشورات لهذا القسم بعد. يمكنك إضافتها من لوحة التحكم.</div>';
 $$('[data-fb-filter]').forEach(btn=>btn.classList.toggle('active',btn.dataset.fbFilter===state.fbFilter));
 $$('[data-fb-video]').forEach(b=>b.onclick=()=>openVideo('post:'+b.dataset.fbVideo));
}
function persistCart(){localStorage.setItem('furat_cart',JSON.stringify(state.cart));renderCart();}
function addCart(id){const p=state.products.find(p=>p.id===id);if(!p||p.stock===0)return;const item=state.cart.find(x=>x.id===id);if(item){if(p.stock!==-1&&item.quantity>=p.stock){toast('الكمية المتوفرة لا تسمح بالمزيد');return;}item.quantity=Math.min(item.quantity+1,99);}else state.cart.push({id,quantity:1});persistCart();toast('تمت إضافة المنتج إلى السلة');}
function adjustCart(id,delta){const item=state.cart.find(x=>x.id===id);const p=state.products.find(x=>x.id===id);if(!item||!p)return;item.quantity=Math.max(0,Math.min(99,p.stock===-1?99:p.stock,item.quantity+delta));state.cart=state.cart.filter(x=>x.quantity>0);persistCart();}
function removeCart(id){state.cart=state.cart.filter(x=>x.id!==id);persistCart();}
function cartTotal(){const products=state.cart.map(item=>({item,product:state.products.find(p=>p.id===item.id)})).filter(x=>x.product);return {total:products.reduce((sum,{item,product})=>sum+Number(product.price)*item.quantity,0),uncertain:products.some(({product})=>!Number(product.price))};}
function renderCart(){state.cart=state.cart.filter(x=>state.products.some(p=>p.id===x.id));const count=state.cart.reduce((sum,x)=>sum+x.quantity,0);$('#cart-count').textContent=count;$('#cart-heading-count').textContent=`(${count})`;const {total,uncertain}=cartTotal();$('#cart-total').textContent=uncertain?'يحدد بعد التأكيد':money(total);$('#checkout-total').textContent=uncertain?'يحدد بعد التأكيد':money(total);$('#cart-items').innerHTML=state.cart.length?state.cart.map(item=>{const p=state.products.find(p=>p.id===item.id);return `<div class="cart-item"><div class="cart-mini-art">${imageFor(p)}</div><div class="cart-item-text"><strong>${esc(p.name)}</strong><small>${money(p.price)}</small><div class="quantity-controls"><button aria-label="زيادة" data-qty="${esc(p.id)}" data-delta="1">${svgIcon('plus')}</button><b>${item.quantity}</b><button aria-label="تقليل" data-qty="${esc(p.id)}" data-delta="-1">${svgIcon('minus')}</button></div></div><button class="cart-remove" data-remove="${esc(p.id)}" aria-label="حذف">${svgIcon('trash')}</button></div>`;}).join(''):`<div class="cart-empty">${svgIcon('bag')}<strong>سلتك فارغة حالياً</strong><p>ابدأ باكتشاف منتجاتنا وأضف ما يعجبك.</p></div>`;$$('[data-qty]').forEach(b=>b.onclick=()=>adjustCart(b.dataset.qty,+b.dataset.delta));$$('[data-remove]').forEach(b=>b.onclick=()=>removeCart(b.dataset.remove));$('#checkout-btn').disabled=!state.cart.length;$('#cart-inquiry').hidden=!state.cart.length||!whatsappNumber(state.settings.whatsapp);}
function lockPage(isLocked){document.body.classList.toggle('no-scroll',isLocked);$('#overlay').hidden=!isLocked;}
function openDrawer(){$('#cart-drawer').classList.add('open');$('#cart-drawer').setAttribute('aria-hidden','false');lockPage(true);}
function closeDrawer(){$('#cart-drawer').classList.remove('open');$('#cart-drawer').setAttribute('aria-hidden','true');lockPage(false);}
function openModal(id){closeDrawer();$('#'+id).hidden=false;document.body.classList.add('no-scroll');}
function closeModals(){$$('.modal').forEach(m=>m.hidden=true);$('#video-modal-body').innerHTML='';lockPage(false);}
function openQuick(id){const p=state.products.find(x=>x.id===id);if(!p)return;state.currentProduct=id;const specs=Object.entries(p.specs||{});const app=externalUrl(p.product_url);const vid=externalUrl(p.video_url);$('#quickview-body').className='quickview-body';$('#quickview-body').innerHTML=`<div class="quickview-image">${imageFor(p)}</div><div class="quickview-info"><span class="kicker">${esc(p.category)}</span><h3>${esc(p.name)}</h3>${p.brand||p.model?`<p class="product-model">${esc([p.brand,p.model].filter(Boolean).join(' • '))}</p>`:''}<p>${esc(p.description)||'لا توجد تفاصيل إضافية.'}</p>${specs.length?`<h4 class="spec-heading">المواصفات الفنية</h4><dl class="spec-list">${specs.map(([k,v])=>`<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>`:'<p class="spec-pending">المواصفات التفصيلية لم تُضاف بعد؛ استفسر من المتجر عن الإصدار المطلوب.</p>'}${p.source==='store-ad-previous'?'<p class="spec-pending">المواصفات من إعلان سابق للفرات موبايل وليست بيانات فنية موثّقة من التطبيق؛ يرجى تأكيدها قبل الشراء.</p>':''}<strong>${money(p.price)}</strong><div class="hero-cta"><button id="quick-add" class="btn btn-primary" ${p.stock===0?'disabled':''}>${svgIcon('bag')} أضف إلى السلة</button><button class="btn btn-soft" id="quick-close">إغلاق</button></div>${app?`<p><a href="${esc(app)}" target="_blank" rel="noopener noreferrer">عرض المنتج في التطبيق ↗</a></p>`:''}${vid?`<p><a href="${esc(vid)}" target="_blank" rel="noopener noreferrer">شاهد فيديو المنتج ↗</a></p>`:''}${p.stock===0?'<p class="stock-label">المنتج غير متوفر حالياً.</p>':''}</div>`;$('#quick-add').onclick=()=>{addCart(p.id);closeModals();openDrawer();};$('#quick-close').onclick=closeModals;openModal('quickview-modal');}
function isFacebookLink(raw){try{const u=new URL(raw);const h=u.hostname.toLowerCase();return h==='facebook.com'||h.endsWith('.facebook.com')||h==='fb.watch'||h==='www.fb.watch';}catch{return false;}}
function openVideo(id){
 const v=allStoreVideos().find(x=>x.id===id);if(!v)return;
 const local=clipUrl(v.url);
 if(local){$('#video-modal-body').innerHTML=`<div class="local-video-box"><video controls autoplay playsinline preload="metadata" poster="${esc(assetUrl(v.thumbnail_url))}"><source src="${esc(assetUrl(local))}" type="video/mp4">تعذر تشغيل المقطع.</video><p>${esc(v.title)} — ${esc(v.description)}</p></div>`;openModal('video-modal');return;}
 const yt=videoId(v.url);
 if(yt){$('#video-modal-body').innerHTML=`<iframe src="https://www.youtube-nocookie.com/embed/${yt}?autoplay=1&rel=0" title="${esc(v.title)}" allow="accelerometer;autoplay;encrypted-media;gyroscope;picture-in-picture" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe><p>${esc(v.title)}</p>`;openModal('video-modal');return;}
 const u=externalUrl(v.url);if(!u)return;
 if(isFacebookLink(u)){
  const parsed=new URL(u);const path=parsed.pathname;
  const direct=/\/videos\/|\/reel\/|\/watch\/|\/share\/(?:r|v)\//.test(path)||parsed.hostname==='fb.watch'||parsed.searchParams.has('v');
  if(direct){const player='https://www.facebook.com/plugins/video.php?href='+encodeURIComponent(u)+'&show_text=false&width=650';$('#video-modal-body').innerHTML=`<div class="facebook-video-embed"><iframe src="${esc(player)}" title="${esc(v.title)}" loading="lazy" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe><p>قد يمنع فيسبوك التضمين أو يطلب تسجيل الدخول. استخدم الرابط البديل عند الحاجة.</p><a class="fb-media-link" href="${esc(u)}" target="_blank" rel="noopener noreferrer">مشاهدة الفيديو على فيسبوك ↗</a></div>`;openModal('video-modal');return;}
 }
 window.open(u,'_blank','noopener,noreferrer');
}

async function loadCheckoutAccount() {
  const form = $('#checkout-form');
  const note = $('#checkout-account-note');
  note.hidden = false;
  try {
    const response = await fetch('/api/account/profile', {cache:'no-store'});
    if (!response.ok) return;
    const {customer} = await response.json();
    if (!customer || $('#checkout-modal').hidden) return;
    note.hidden = true;
    if (!form.elements.customer_name.value) form.elements.customer_name.value = customer.name;
  } catch {
    // Checkout remains available while the account endpoint is unreachable.
  }
}

async function submitOrder(e){e.preventDefault();const btn=$('#submit-order');btn.disabled=true;btn.textContent='جارٍ إرسال الطلب...';const form=new FormData(e.currentTarget);const payload=Object.fromEntries(form.entries());payload.items=state.cart.map(x=>({id:x.id,quantity:x.quantity}));try{const res=await fetch('/api/orders',{method:'POST',headers:{'Content-Type':'application/json','X-Store-Action':'customer'},body:JSON.stringify(payload)});const data=await res.json();if(!res.ok)throw new Error(typeof data.detail==='string'?data.detail:'تعذر إرسال الطلب؛ تأكد من البيانات');state.cart=[];persistCart();$('#checkout-form').hidden=true;const wa=whatsappNumber(state.settings.whatsapp);const lines=data.items.map(i=>`• ${i.name} × ${i.quantity}`).join('\n');const msg=`طلب جديد من متجر الفرات موبايل\nرقم الطلب: ${data.order_id}\nالاسم: ${payload.customer_name}\nالجوال: ${payload.phone}\nالمدينة: ${payload.city}\nالعنوان: ${payload.address}\nالمنتجات:\n${lines}`;$('#order-success').hidden=false;$('#order-success').innerHTML=`<div class="success-mark">${svgIcon('check')}</div><h3>وصل طلبك بنجاح!</h3><p>تم تسجيل طلبك في لوحة إدارة المتجر. احتفظ برقم الطلب للمتابعة. سيتم تأكيد التوفر والسعر النهائي وطريقة الدفع معك.</p><span class="order-id">${esc(data.order_id)}</span>${wa?`<a class="btn btn-primary btn-wide" target="_blank" rel="noopener noreferrer" href="https://wa.me/${wa}?text=${encodeURIComponent(msg)}">${svgIcon('whatsapp')} أرسل تفاصيل الطلب على واتساب</a>`:''}<button type="button" class="btn btn-soft btn-wide" style="margin-top:10px" id="close-success">العودة إلى المتجر</button>`;$('#close-success').onclick=closeModals;}catch(err){toast(err.message||'حدث خطأ أثناء الطلب');}finally{btn.disabled=false;btn.innerHTML='إرسال الطلب '+svgIcon('check');}}
async function loadCatalog(){try{const r=await fetch('/api/catalog',{cache:'no-store'});if(!r.ok)throw new Error('تعذر تحميل البيانات');const data=await r.json();state.settings=data.settings||{};state.products=data.products||[];state.videos=data.videos||[];state.social_posts=data.social_posts||[];applySettings();renderCategories();renderFilters();renderProducts();renderVideos();renderFacebook();renderCart();$('#demo-note').hidden=!data.demo;}catch(err){$('#product-grid').innerHTML='<div class="videos-empty">تعذر الوصول إلى المتجر. أعد تشغيل الخادم وحاول تحديث الصفحة.</div>';toast(err.message);}}
function initEvents(){$$('[data-fb-filter]').forEach(btn=>btn.addEventListener('click',()=>{state.fbFilter=btn.dataset.fbFilter;renderFacebook();}));$('#product-search').addEventListener('input',e=>{state.search=e.target.value;renderProducts();});$('#header-search').onclick=()=>{$('#products').scrollIntoView({behavior:'smooth'});setTimeout(()=>$('#product-search').focus(),500);};$('#sort-products').onchange=e=>{state.sort=e.target.value;renderProducts();};$('#reset-filters').onclick=()=>{state.filter='الكل';state.search='';$('#product-search').value='';renderFilters();renderProducts();};$('#open-cart').onclick=openDrawer;$('#mobile-cart').onclick=openDrawer;$('#checkout-btn').onclick=()=>{if(!state.cart.length)return;$('#checkout-form').hidden=false;$('#order-success').hidden=true;$('#checkout-form').reset();openModal('checkout-modal');loadCheckoutAccount();};$('#cart-inquiry').onclick=inquireAboutCart;$('#checkout-form').onsubmit=submitOrder;$('#overlay').onclick=closeDrawer;$$('[data-close="drawer"]').forEach(b=>b.onclick=closeDrawer);$$('[data-close="modal"]').forEach(b=>b.onclick=closeModals);$$('.modal').forEach(m=>m.addEventListener('click',e=>{if(e.target===m)closeModals();}));document.onkeydown=e=>{if(e.key==='Escape'){closeModals();closeDrawer();}};$('#menu-toggle').onclick=()=>{$('#mobile-menu').hidden=!$('#mobile-menu').hidden;};$$('#mobile-menu a').forEach(a=>a.onclick=()=>{$('#mobile-menu').hidden=true;});const theme=localStorage.getItem('furat_theme');if(theme==='light')document.body.classList.add('light-mode');$('#theme-toggle').onclick=()=>{document.body.classList.toggle('light-mode');localStorage.setItem('furat_theme',document.body.classList.contains('light-mode')?'light':'dark');};document.addEventListener('scroll',()=>{const links=$$('.desktop-nav .nav-link');let current='top';['top','categories','products','facebook','videos','contact'].forEach(id=>{const el=$('#'+id);if(el&&el.getBoundingClientRect().top<180)current=id;});links.forEach(a=>a.classList.toggle('active',a.getAttribute('href')==='#'+current));},{passive:true});}
initEvents();reveal();loadCatalog();
if('serviceWorker' in navigator&&location.protocol==='https:')navigator.serviceWorker.register('/sw.js').catch(()=>{});
