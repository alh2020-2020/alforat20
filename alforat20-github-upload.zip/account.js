'use strict';

const form = document.querySelector('#account-form');
const status = document.querySelector('#account-status');
const submit = document.querySelector('#account-submit');
const auth = document.querySelector('#account-auth');
const profile = document.querySelector('#account-profile');
const orders = document.querySelector('#customer-orders');
const modes = [...document.querySelectorAll('[data-mode]')];
let mode = 'login';

function message(text = '', error = false) {
  status.textContent = text;
  status.dataset.error = String(error);
}

async function accountRequest(path, data) {
  const response = await fetch('/api/account' + path, {
    cache: 'no-store',
    ...(data && {
      method: 'POST',
      headers: {'Content-Type': 'application/json', 'X-Store-Action': 'customer'},
      body: JSON.stringify(data)
    })
  });
  const result = await response.json();
  if (!response.ok) {
    const detail = typeof result.detail === 'string' ? result.detail : 'تحقق من البيانات وحاول مجددًا.';
    throw new Error(detail);
  }
  return result;
}

function setMode(next) {
  mode = next;
  const registering = mode === 'register';
  const name = form.elements.name;
  name.disabled = !registering;
  name.required = registering;
  document.querySelector('#account-name').hidden = !registering;
  document.querySelector('#password-hint').hidden = !registering;
  form.elements.password.minLength = registering ? 12 : 1;
  form.elements.password.autocomplete = registering ? 'new-password' : 'current-password';
  submit.textContent = registering ? 'إنشاء حساب' : 'تسجيل الدخول';
  modes.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.mode === mode)));
  message();
}

function node(tag, text, className) {
  const element = document.createElement(tag);
  if (text) element.textContent = text;
  if (className) element.className = className;
  return element;
}

function renderOrders(items, currency) {
  orders.replaceChildren();
  if (!items.length) {
    const link = node('a', 'تصفح المنتجات', 'btn btn-primary');
    link.href = '/#products';
    orders.append(node('p', 'ستظهر هنا الطلبات التي ترسلها بعد تسجيل الدخول.'), link);
    return;
  }
  for (const order of items) {
    const card = node('article', '', 'account-card');
    const title = node('h3', '', 'order-title');
    const id = node('bdi', order.id);
    title.append('طلب ', id);
    const date = new Date(order.created_at).toLocaleDateString('ar-YE');
    const list = node('ul', '', 'order-items');
    for (const item of order.items) list.append(node('li', `${item.name} × ${item.quantity}`));
    const total = order.items.some(item => !Number(item.price))
      ? 'يُحدّد بعد تأكيد المتجر'
      : new Intl.NumberFormat('ar-YE').format(order.total) + ' ' + currency;
    card.append(title, node('p', `${order.status} · ${date}`), list, node('p', 'الإجمالي المبدئي ' + total));
    orders.append(card);
  }
}

async function refreshAccount() {
  const result = await accountRequest('');
  if (result.customer) {
    document.querySelector('#customer-name').textContent = result.customer.name;
    document.querySelector('#customer-email').textContent = result.customer.email;
    renderOrders(result.orders, result.currency);
  } else {
    orders.replaceChildren();
  }
  auth.hidden = Boolean(result.customer);
  profile.hidden = !result.customer;
  message();
}

modes.forEach(button => button.onclick = () => setMode(button.dataset.mode));
form.onsubmit = async event => {
  event.preventDefault();
  submit.disabled = true;
  modes.forEach(button => button.disabled = true);
  message('جارٍ التحقق…');
  try {
    await accountRequest('/' + mode, Object.fromEntries(new FormData(form)));
    form.reset();
    await refreshAccount();
    document.querySelector('h1').scrollIntoView();
  } catch (error) {
    message(error.message, true);
  } finally {
    submit.disabled = false;
    modes.forEach(button => button.disabled = false);
  }
};

document.querySelector('#account-logout').onclick = async event => {
  const button = event.currentTarget;
  button.disabled = true;
  try {
    await accountRequest('/logout', {});
    await refreshAccount();
    setMode('login');
  } catch (error) {
    message(error.message, true);
  } finally {
    button.disabled = false;
  }
};

refreshAccount().catch(() => message('تعذر تحميل الحساب. أعد تحميل الصفحة للمحاولة مرة أخرى.', true));
